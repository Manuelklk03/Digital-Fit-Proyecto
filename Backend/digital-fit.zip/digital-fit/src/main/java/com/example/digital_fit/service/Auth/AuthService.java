package com.example.digital_fit.service.Auth;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.digital_fit.dto.Admin.CrearAdmin;
import com.example.digital_fit.dto.Auth.UsuarioDTO;
import com.example.digital_fit.dto.Auth.UsuarioSesionDTO;
import com.example.digital_fit.exception.EmailYaExisteException;
import com.example.digital_fit.exception.RecursoNoEncontradoException;
import com.example.digital_fit.exception.UsernameYaExiste;
import com.example.digital_fit.model.Auth.Usuario;
import com.example.digital_fit.model.Enums.Rol;
import com.example.digital_fit.repository.Auth.UsuarioRepository;

import jakarta.transaction.Transactional;

@Service
public class AuthService {

    private static final Logger log = LoggerFactory.getLogger(AuthService.class);

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // Registrar usuario:
    @Transactional
    public void registrar(UsuarioDTO usuarioDTO) {

        log.info("Registrando usuario: {}", usuarioDTO.getUsername());

        if (usuarioRepository.findByUsername(usuarioDTO.getUsername()).isPresent()) {
            log.warn("Usuario no creado,username ya existente {}", usuarioDTO.getUsername());
            throw new UsernameYaExiste("Nombre de usuario ya existe");
        }

        if (usuarioRepository.findByEmail(usuarioDTO.getEmail()).isPresent()) {
            throw new EmailYaExisteException("Email ya existe");
        }

        Usuario usuario = Usuario.builder()
                .username(usuarioDTO.getUsername())
                .email(usuarioDTO.getEmail())
                .password(passwordEncoder.encode(usuarioDTO.getPassword()))
                .rol(Rol.USER)
                .build();

        usuarioRepository.save(usuario);

        log.info("Usuario registrado exitosamente {}", usuario.getUsername());
    }

    // Registrar admin:
    @Transactional
    public void registrarAdmin(CrearAdmin crearAdmin) {

        log.info("Creacion de administrador {}", crearAdmin.getUsername());

        if (usuarioRepository.findByUsername(crearAdmin.getUsername()).isPresent()) {
            log.warn("Admin no creado,username ya existente {}", crearAdmin.getUsername());

            throw new UsernameYaExiste("Nombre de usuario ya existe");
        }

        Usuario admin = new Usuario();

        admin.setUsername(crearAdmin.getUsername());
        admin.setPassword(passwordEncoder.encode(crearAdmin.getPassword()));
        admin.setEmail(crearAdmin.getUsername());
        admin.setRol(Rol.ADMIN);

        usuarioRepository.save(admin);

        log.info("Admin creado exitosamente {}", admin.getUsername());
    }

    // Metodo que obtiene sesion (Admin o user)
    public UsuarioSesionDTO obtenerSesion(String username) {
        Usuario usuario = usuarioRepository.findByUsername(username).orElseThrow(
                () -> new RecursoNoEncontradoException("No se encuentra el usuario"));

        return new UsuarioSesionDTO(usuario.getUsername(), usuario.getEmail(), usuario.getRol());
    }

}
